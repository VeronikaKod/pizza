
from tkinter import *
from tkinter import messagebox

window = Tk()
window.title("Заказ пиццы")
window.geometry("1000x500")

def append():
    itog = ""
    if int(var.get()) == 1:
        itog += "Маленькая пицца"
    if int(var.get()) == 2:
        itog += "Средняя пицца"
    if int(var.get()) == 3:
        itog += "Большая пицца"  
    if int(var.get()) == 0:
        messagebox.showerror("Ошибка", "Обязательно выберите размер пиццы")       
    if int(var1.get()) == 1:
        itog += ",с доп порцией грибов"
    if int(var2.get()) == 1:
        itog += ",с доп порцией сырочка"
    if int(var3.get()) == 1:
        itog += ",с доп порцией бекончика"
    if entry.get() != "" or entry.get() != None:
        itog += entry.get() + "."

    list.insert(0,itog)
    
def delit():
    list.delete(0, END)

lab=Label(window, text="Выбери размер пиццы")
lab.place(x = 20, y=20)
var = IntVar()
radio = Radiobutton(window, text="Маленькая", variable=var, value=1)
radio.place(x=20, y =55)
radio1 = Radiobutton(window, text="Средняя", variable=var, value= 2)
radio1.place(x=20, y =85)
radio2 = Radiobutton(window, text="Большая", variable=var, value= 3)
radio2.place(x=20, y =115)

lab1=Label(window, text="Выбери дополнительные ингредиенты")
lab1.place(x = 20, y=165)
var1 = IntVar()
check = Checkbutton(window, text="Грибы", variable=var1)
check.place(x=20, y=200)
var2 = IntVar()
check1 = Checkbutton(window, text="Сырочек", variable=var2)
check1.place(x=20, y=230)
var3 = IntVar()
check2 = Checkbutton(window, text="Бекончик", variable=var3)
check2.place(x=20, y=260)

lab1=Label(window, text="Дополнительный коментарий к заказу")
lab1.place(x = 20, y=310)
entry = Entry(window)
entry.place(x=30, y=345)

but = Button(window, text="Добавить заказ", command=append)
but.place(x=50, y=390)

list = Listbox(window, width=100, height=10)
list.place(x=360, y=60)

but1 = Button(window, text="Очистить список заказов", command=delit)
but1.place(x=360, y=20)

window.mainloop()